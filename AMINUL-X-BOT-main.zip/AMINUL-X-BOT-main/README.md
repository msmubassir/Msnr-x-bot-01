This bot create by Aminul Sordar 
